import React, { useState } from 'react'

const EditButton = (props) => {

    const [buttonClicked, setButtonClicked] = useState(false);

    const hideButton = () => {
        setButtonClicked(true);
    }

    const showButton = () => {
        setButtonClicked(false);
    }

    return <div className='new-expense'>
        {!buttonClicked && <button type='submit' onClick={hideButton}>Show</button>}
        {buttonClicked && <div><p>Button clicked</p> <button type='submit' onClick={showButton}>Hide</button></div>}
    </div>
}


export default EditButton;