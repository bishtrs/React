import './ExpenseItem.css';
import './Expenses.css';
import Card from '../UI/Card';
import ExpensesFilter from './ExpensesFilter';
import { useState } from 'react';
import ExpensesList from './ExpensesList';
import ExpenseChart from './ExpenseChart';

function Expenses(props) {

    const [selectedDate, setSelectedDate] = useState('2020');
    const dateSelectHandler = (selectedDate) => {
        console.log('In Expenses.js');
        console.log(selectedDate);
        //props.onAddExpense(expenseData);
        setSelectedDate(selectedDate);
        console.log(props.expenses);
    };

    const filteredExpenses = props.expenses.filter(expenses => {
        console.log(expenses.date);
        return expenses.date.getFullYear().toString() === selectedDate
    });

    return (
        <Card className='expenses'>
            <ExpensesFilter selected={selectedDate} onDateSelection={dateSelectHandler} />
            <ExpenseChart expenses={filteredExpenses} />
            <ExpensesList items={filteredExpenses} />
        </Card>
    )
}

export default Expenses;