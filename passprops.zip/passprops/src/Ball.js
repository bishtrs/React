import Label from './Label';

function Ball(props) {
  console.log(props);
  return (
    <div>
      {props.balls.map((ball) => (
        <Label name={ball.name} color={ball.color}
        />
      ))}
    </div>
  );
}

export default Ball;
