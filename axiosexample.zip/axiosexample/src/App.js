import Button from './Button';
import './App.css';

function App() {
  return (
    <Button />
  );
}

export default App;
