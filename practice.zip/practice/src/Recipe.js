export function Recipe({ name, ingredients }) {
  return (
    <div>
      <h1>{name}</h1>
      <ul>
        {ingredients.map((ingredient, i) => (
          <li key={i}>{ingredient.name}</li>
        ))}
      </ul>
    </div>
  );
}
