import EditButton from './EditButton';
import './App.css';

function App() {
  return (
    <EditButton />
  );
}

export default App;
