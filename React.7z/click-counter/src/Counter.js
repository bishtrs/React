import { useState } from "react";

function Counter() {
    const [counter, setCounter] = useState(0);
  
    const clickHandler = () => {
      setCounter(counter+1);
    }
  
    const resetHandler = () => {
      setCounter(0);
    }
    
    
    return (
      <div className="App">
        <p>Counter {counter}</p>
        <button onClick={clickHandler}>Click</button><br></br>
        <button onClick={resetHandler}>Reset</button>
      </div>
    );
  }

  export default Counter;