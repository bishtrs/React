function Label(props) {
    console.log(props);
  return (
    <div>
      <p>This is a {props.name}, and its color is {props.color}</p>
    </div>
  );
}

export default Label;
