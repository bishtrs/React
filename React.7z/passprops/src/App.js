import Ball from './Ball';

const balls = [{name:'Football', color:'blue'}, {name:'Cricket Ball', color:'red'}]

function App() {
  return (
    <Ball balls={balls}/>
  );
}

export default App;
