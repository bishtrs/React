import './App.css';
import { Recipe } from './Recipe';

const data = [{
  name: "Baked Salmon",
  ingredients: [
    { name: "Salmon", amount: 1, measurement: "1 lb" },
    { name: "Pine nuts", amount: 1, measurement: "cup" }
  ]
},
{
  name: "Fish Tacos",
  ingredients: [
    { name: "Whietefish", amount: 1, measurement: "1 lb" },
    { name: "Cheese", amount: 1, measurement: "cup" }
  ]
}]

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Delicious Recipes</h1>
        {
          data.map((dt, i) => (
            <Recipe key={i} name={dt.name} ingredients={dt.ingredients} />
          )
          )}
      </header>
    </div>
  );
}

export default App;
